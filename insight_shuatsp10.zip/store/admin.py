from django.contrib import admin
from store.models import Registration
from store.models import Category
from store.models import Events
from store.models import Contact
from store.models import Order_event
from store.models import front_event
from store.models import front_category
from store.models import gallery
from store.models import corousel
from store.models import about
from store.models import front_register
from store.models import front_gallery
from store.models import front_contact
from store.models import contact_detail
from store.models import top_details
# Register your models here.

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

class AdminEvents(admin.ModelAdmin):
    list_display = ['event_name','event_price','Category','written_by']

    def get_queryset(self, request):
        Events.get_Event_by_user(self,request)
        if request.user.is_superuser:
            queryset = Events.objects.all()
        else:
            try:
                queryset =Events.objects.filter(Coordinator__id=request.user.id)
            except:
                queryset = Events.objects.none()
        return queryset

class AdminOrder_event(admin.ModelAdmin):

    list_display = ['s_name','events','e_attendance']

    def get_readonly_fields(self, request, obj=None):
        if request.user.is_superuser:
            return[]
        else:
            if obj:
                return['s_id','s_name','events','price','date']

    def get_queryset(self, request,l=[]):
        l= Events.get_Event_by_user(self,request)
        if request.user.is_superuser:
            queryset = Order_event.objects.all()
        else:
            try:
                queryset =Order_event.objects.filter(events__in =l)
            except:
                queryset = Order_event.objects.none()
        return queryset

class Adminfront_category(admin.ModelAdmin):
    list_display = ['name']



class Adminfront_event(admin.ModelAdmin):
    list_display = ['event_name','category']



admin.site.register(Registration)
admin.site.register(Category,AdminCategory)
admin.site.register(Events,AdminEvents)
admin.site.register(Contact)
admin.site.register(Order_event,AdminOrder_event)
admin.site.register(front_category,Adminfront_category)
admin.site.register(front_event,Adminfront_event)
admin.site.register(gallery)
admin.site.register(corousel)
admin.site.register(about)
admin.site.register(front_register)
admin.site.register(front_gallery)
admin.site.register(front_contact)
admin.site.register(contact_detail)
admin.site.register(top_details)